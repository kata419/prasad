import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  sharedDataObj:any ={};
  private headercmr = new BehaviorSubject('true');
  setheadercmr = this.headercmr.asObservable();
  private uploadedFilesData = {};  

  apiUrl: string = 'https://localhost/api/';  // add your url
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private httpClient: HttpClient) { }

  
// Added By Varaprasad on 02-July
setUploadedFilesInfo(uploadedFilesData) {      
  this.uploadedFilesData = uploadedFilesData;  
}  

getUploadedFilesInfo() {  
  return this.uploadedFilesData;  
} 

changecmr(message) {
  this.headercmr.next(message);
  console.log(message);
}
  /* Get loadCMRVideoUrls */
  loadCMRVideoUrls(inputObj: any){
    return this.httpClient.get<any>(this.apiUrl)
    .pipe(map(data => {
       // data = 'This is sample response';
        return data;
    }));
  }

   /* Start Usage Statistics */
   usageStatistics(flag: any){
   return this.httpClient.get<any>('https://localhost/api/diskstatistics/'+flag+'/usagecsv')
    .pipe(map(data => {
        return data;
    }));
  }


  getDriveStatistics(){
    return this.httpClient.get<any>('https://localhost/api/diskstatistics/StopStatistics/usagecsv')
    .pipe(map(data => {
        return data;
    }));
  }

  //  Copy files to media

  copyFilesToMedia(inputObj: any){
  return this.httpClient.post('https://localhost/api/diskstatistics/dummy/copyfiles', {'params':inputObj})
    .pipe(map(data => {
      return data;
  }));
  }

  // Files Progress 

  progressFilesToMedia(inputObj: any){
  return this.httpClient.post('https://localhost/api/diskstatistics/dummy/filepercentage', {'params':inputObj})
    .pipe(map(data => {
      return data;
  }));
  }
  

    stopcopying(){
    return this.httpClient.get<any>('https://localhost/api/diskstatistics/StopStatistics/usagecsv')
    .pipe(map(data => {
        return data;
    }));
  }
  
}
