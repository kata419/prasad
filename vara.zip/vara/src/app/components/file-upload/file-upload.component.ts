import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CommonService } from '../../services/common.service'
import { ThemePalette } from '@angular/material/core';
import { ProgressBarMode } from '@angular/material/progress-bar';
import { timer, Observable, Subscription } from 'rxjs';
import { ActivatedRoute, NavigationEnd, Router, Route } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  destinationPath: any;
  sourcePath: any;
  selectedFiles: any[] = [];

  showStopExit: boolean = false;
  // Progress bar

  color: ThemePalette = 'primary';
  mode: ProgressBarMode = 'buffer';
  value = 50;
  bufferValue: number;
  timer: any;


  // timer
  hours: any;
  minutes: any;
  seconds: any;
  showTimer: boolean = false;
  copyData: any = {};
  sectionName: any;
  private subscriptions: Subscription[] = [];
  everySecond$: Observable<number> = timer(0, 1000);


  // Sharing message to drive-message-component
  @Output() redirect: EventEmitter<any> = new EventEmitter();
  messageText: any;
  totalSeconds: any = 0;
  intervalId: any = null;






  constructor(private _commonService: CommonService, private _router: Router, private route: ActivatedRoute, private location: Location) { }
  ngOnInit(): void {

   // this.sectionName = this.route.snapshot.paramMap.get('relativeTo');
    this.sectionName = this.route.snapshot.queryParams; 
    this.location.replaceState('file-upload');

  }
  setTimer(){
    ++this.totalSeconds;
    this.hours = Math.floor(this.totalSeconds /3600);
    this.minutes = Math.floor((this.totalSeconds - this.hours*3600)/60);
    this.seconds = this.totalSeconds - (this.hours*3600 + this.minutes*60);
    console.log(this.hours+":"+this.minutes+":"+this.seconds);
  }
  stopTimer(){
    if (this.intervalId)
    clearInterval(this.intervalId);
  }


  onSubmit() {

  }
  handleFileInput(files: FileList) {
    console.log(files);
    for (let i = 0; i < files.length; i++) {
      this.selectedFiles.push(files[i].name);
    }

    console.log(' this.selectedFiles--' + this.selectedFiles + '    --sourcePath---' + this.sourcePath + '---destinationPath---' + this.destinationPath);
  }


  copyFilestoMedia() {
    this.intervalId = setInterval(() => this.setTimer(),1000);
    this.showTimer = true;
    this.showStopExit = true;
    let sourcePathList = [];
    //   this.selectedFiles.forEach(item =>{
    //     sourcePathList.push(this.sourcePath+'/'+item)
    //   })
    //   console.log(sourcePathList);
    //   this.selectedFiles = [];
    //    sourcePathList.forEach(item =>{
    //     this.selectedFiles.push(item.replace(/\\/g, "/"));
    //    })

    //  console.log( this.selectedFiles);
    //  this.selectedFiles = [...new Set(this.selectedFiles)];
    //  this.destinationPath = this.destinationPath.replace(/\\/g, "/");
    this.sourcePath = this.sourcePath.replace(/\\/g, "/");
    this.destinationPath = this.destinationPath.replace(/\\/g, "/");
    let inputObj = {
      'source': this.sourcePath,
      'destination': this.destinationPath
    }

    console.log('input Obj--', inputObj);
    // this.startTimer();

    this._commonService.copyFilesToMedia(inputObj).subscribe((data) => {
      console.log('this is response --', data);

      this.copyData = data;

      // if(res){

      // this.timer = setInterval(() => this.startProgressBar(inputObj), 10000)
      //  }
    });


    console.log(' sourcePathList--' + sourcePathList + '---destinationPath---' + this.destinationPath);
  }

  // startTimer() {
  //   this.showTimer = true;
  //   //     this.subscription = this.timer$.subscribe(seconds => this.time_convert(seconds) );
  //   // console.log(this.subscription);
  //   if(this.bufferValue != 100)
  //   {
  //     this.subscriptions.push(this.everySecond$.subscribe(second => this.time_convert(second)));
  //   }
  //   //this.subscriptions.push(this.everySecond$.subscribe(second => this.time_convert(second)));
  //   if(this.bufferValue == 100)
  //   {
  //     //this.everySecond$.unsubscribe();
  //     //this.everySecond$.unsubscribe();
  //     //this.subscriptions.unsubscribe();
  //     //this.timer.unsubscribe();
  //     this.subscriptions = [];
  //   }


  // }

  // time_convert(num: number) {
  //   this.hours = Math.floor(num / 3600);;
  //   num %= 3600;
  //   this.minutes = Math.floor(num / 60);
  //   this.seconds = num % 60;
  //   // console.log(this.hours, this.minutes, this.seconds);
  // }






  async startProgressBar(inputObj: any) {
  
    

    this._commonService.progressFilesToMedia(inputObj).subscribe((data) => {
      console.log('progress value --', data);
      this.copyData = data;
      


      this.bufferValue = this.copyData.msg.percentagecopied;
      console.log('buffer value1 --', this.bufferValue);

      if (this.bufferValue == 100) {
        this.showTimer = true;
        this.showStopExit = false;
        console.log('buffer value2 --', this.bufferValue);
        clearInterval(this.timer);
      }
      else if (this.bufferValue != 100) {
        this.showTimer = true;
        this.showStopExit = true;
        console.log('buffer value2 --', this.bufferValue);
        //clearInterval(this.timer);
      }
    });

  }


  stopExit() {
    this.stopTimer()
    clearInterval(this.timer);
    console.log(this.sectionName );
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.messageText = 'You have successfully stopped / completed copying files';
    this.redirect.emit(this.messageText);
    if (this.sectionName.driveName == 'CMR') {
      this._router.navigateByUrl('/copyfiles-mediamsg');
    } else {
      this._router.navigateByUrl('/media-charts');
    }
  }
}
