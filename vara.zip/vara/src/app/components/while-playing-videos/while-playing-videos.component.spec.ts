import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhilePlayingVideosComponent } from './while-playing-videos.component';

describe('WhilePlayingVideosComponent', () => {
  let component: WhilePlayingVideosComponent;
  let fixture: ComponentFixture<WhilePlayingVideosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhilePlayingVideosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhilePlayingVideosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
