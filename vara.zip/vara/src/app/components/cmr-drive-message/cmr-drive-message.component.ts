import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmr-drive-message',
  templateUrl: './cmr-drive-message.component.html',
  styleUrls: ['./cmr-drive-message.component.css']
})
export class CmrDriveMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
