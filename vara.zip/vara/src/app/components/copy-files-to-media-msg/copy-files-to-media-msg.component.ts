import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-copy-files-to-media-msg',
  templateUrl: './copy-files-to-media-msg.component.html',
  styleUrls: ['./copy-files-to-media-msg.component.css']
})
export class CopyFilesToMediaMsgComponent implements OnInit {

  constructor(private _router : Router) { }

  ngOnInit(): void {
    setTimeout(() => {
      this._router.navigateByUrl('/home');
      }, 10000);
  }

}
