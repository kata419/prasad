import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from '../services/common.service'
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { timeout } from 'rxjs/operators';




@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  playSameVideosCountCMR: string;
  playDiffVideosCountCMR: any;
  copyFilesToMediaCountCMR: any;
  copySameFilesWhilePlayVideosCountCMR: any;
  copyDiffFilesWhilePlayVideosCountCMR: any;

  playSameVideosCountSMR: string;
  playDiffVideosCountSMR: any;
  copyFilesToMediaCountSMR: any;
  copySameFilesWhilePlayVideosCountSMR: any;
  copyDiffFilesWhilePlayVideosCountSMR: any;
  headercmr:any;
  showModal: boolean;
  modalHeaderText: any;
  inputObj: any;
  showMessage: boolean;
  selectMultipleFiles: boolean;

  @ViewChild('fileType') fileUploadField: ElementRef;



  constructor(private _router: Router, private _activatedRoute: ActivatedRoute, private _commonService: CommonService, ) { }

  ngOnInit() {
    this._commonService.setheadercmr.subscribe((message) =>{

     this.headercmr = message;
    console.log(this.headercmr);
    });
  }
  goToAboutPage() {
    window.open("https://www.westerndigital.com/products/data-center-drives/ultrastar-dc-hc600-series-hdd", "_blank");
  }
  playSameVideos(driveName: any, count) {
    if(count > 0 && count <= 100) {
    console.log('playSameVideosCount--', driveName, count);
    if (driveName === 'CMR') {
      this.playSameVideosCountCMR = null;
    }
    if (driveName === 'SMR') {
      this.playSameVideosCountSMR = null;
    }

    this.inputObj = {
      'driveName': driveName,
      'count': count,
      'itemType': 'same'
    }
    this.showModal = true;
    this.fileUploadField.nativeElement.value = '';
    this.selectMultipleFiles = false;

    // alert('Please browse the videos path to play the selected videos');
    this.modalHeaderText = 'Please browse the videos path to play the selected videos';
    // this._router.navigate(['/compare-videos' ,JSON.stringify(inputObj)]);
  } else {
    alert("please Enter positive count value,count should be in range 1-100");
    this.playSameVideosCountCMR = null;
    this.playSameVideosCountSMR = null;
  }

  }
  playDiffVideos(driveName: any, count) {
    if(count > 0 && count <= 100 ){
    console.log('playDiffVideosCount--', driveName, count);
    if (driveName === 'CMR') {
      this.playDiffVideosCountCMR = null;
    }
    if (driveName === 'SMR') {
      this.playDiffVideosCountSMR = null;
    }

    this.inputObj = {
      'driveName': driveName,
      'count': count,
      'itemType': 'different'
    }

    this.showModal = true;
    this.fileUploadField.nativeElement.value = '';
    this.selectMultipleFiles = true;
    this.modalHeaderText = 'Please browse the videos path to play the selected videos';


    // this._router.navigateByUrl('/compare-videos');
  }else {
    alert("please Enter positive count value,count should be in range 1-100");
    this.playDiffVideosCountCMR = null;
    this.playDiffVideosCountSMR = null;
  }

  }
  copyFilesToMedia(driveName: any, count) {
    // if(count > 0){
    console.log('copyFilesToMediaCount----', driveName, count);
    if (driveName === 'CMR') {
      this.copyFilesToMediaCountCMR = null;
    }
    if (driveName === 'SMR') {
      this.copyFilesToMediaCountSMR = null;
    }

    this.inputObj = {
      'driveName': driveName,
      'count': count
    }

    // this.showModal = true;
    // this.fileUploadField.nativeElement.value = '';
    // this.selectMultipleFiles = true;
    // this.modalHeaderText = 'Please browse the videos path to play the selected videos';

    // this._router.navigateByUrl('/file-upload');
    this._router.navigate(['file-upload'], { queryParams: this.inputObj});
  // }else {
  //   alert("please Enter positive count value");
  //   this.copyFilesToMediaCountCMR = null;
  //   this.copyFilesToMediaCountSMR = null;
  // }
    

  }
  copySameFilesWhilePlayVideos(driveName: any, count) {
    if(count > 0){
    console.log('copySameFilesWhilePlayVideosCount----', driveName, count);
    if (driveName === 'CMR') {
      this.copySameFilesWhilePlayVideosCountCMR = null;
    }
    if (driveName === 'SMR') {
      this.copySameFilesWhilePlayVideosCountSMR = null;
    }

    this.inputObj = {
      'driveName': driveName,
      'count': count,
      'itemType': 'same'
    }

    // this.showModal = true;
    this.fileUploadField.nativeElement.value = '';
    this.selectMultipleFiles = false;
    this.modalHeaderText = 'Please browse the videos path to play the selected videos';

    //  this._router.navigateByUrl('/while-play-videos');
     this._router.navigate(['while-play-videos'], { queryParams: this.inputObj});
  }else {
    alert("please Enter positive count value");
    this.copySameFilesWhilePlayVideosCountCMR = null;
    this.copySameFilesWhilePlayVideosCountSMR = null;
  }

  }
  copyDiffFilesWhilePlayVideos(driveName: any, count) {
    if(count > 0){
    console.log('copyDiffFilesWhilePlayVideosCount---', driveName, count);
    if (driveName === 'CMR') {
      this.copyDiffFilesWhilePlayVideosCountCMR = null;
    }
    if (driveName === 'SMR') {
      this.copyDiffFilesWhilePlayVideosCountSMR = null;
    }

    this.inputObj = {
      'driveName': driveName,
      'count': count,
      'itemType': 'different'
    }

    // this.showModal = true;
    this.fileUploadField.nativeElement.value = '';
    this.selectMultipleFiles = true;
    this.modalHeaderText = 'Please browse the videos path to play the selected videos';

    // this._router.navigateByUrl('/while-play-videos');
    this._router.navigate(['while-play-videos'], { queryParams: this.inputObj});
  }else {
    alert("please Enter positive count value");
    this.copyDiffFilesWhilePlayVideosCountCMR = null;
    this.copyDiffFilesWhilePlayVideosCountSMR = null;
  }

  }

  pauseVideos(driveName: any) {
    alert('This is Pause Videos---' + driveName);
  }

  stopVideos(driveName: any) {
    alert('This is Stop Videos---' + driveName);
  }




  handleFileInput(filepath: any) {
let data = JSON.parse(JSON.stringify(filepath));
    console.dir('value--'+filepath.target.value);

    console.dir('result--'+filepath.target.result);


    let url: any, format: any, fileProperties: any;
    this.inputObj['uploadedFiles'] = [];
    console.log('filepath--',filepath);

    //console.log('filepath--', filepath.path.window);

    // let file = filepath.target.files && filepath.target.files[0];
    let file = filepath.target.files;
    console.log('file---', file);


    if (file) {
    
      for (let i = 0; i < file.length; i++) {
        var reader = new FileReader();
        reader.readAsDataURL(file[i]);
        if (file[i].type.indexOf('image') > -1) {
          format = 'image';
        } else if (file[i].type.indexOf('video') > -1) {
          format = 'video';
        }

        reader.onload = (event) => {


          


          url = (<FileReader>event.target).result;
          console.log(JSON.stringify(url));
          fileProperties = {
            'fileType': file[i].type,
            'file': url
          }

          this.inputObj['uploadedFiles'].push(fileProperties);

          // this.inputObj['fileType'] = filepath.target.files[0].type;

          


          console.log('input obj--', this.inputObj.count,  this.inputObj.uploadedFiles.length);

         


        //  console.log('result--', this.inputObj.count,  this.inputObj.uploadedFiles.length, largeVal, smallVal, result, typeof(result));
        
        // this.replicateArray(this.inputObj.uploadedFiles, quotient);
         
       //  console.log(' count-- '+this.inputObj.count+' files length-- '+ this.inputObj.uploadedFiles.length+ ' large val-- '+ largeVal +' small val-- '+ smallVal +' result-- '+result, typeof(result));
         this._commonService.setUploadedFilesInfo(this.inputObj);
        }
      }
      console.log("--1", this.inputObj);
      this.showMessage = true;
      setTimeout(() => {
        this.showMessage = false;
        this.hide();
        this._router.navigateByUrl('/compare-videos');
      }, 3000);
    }
    console.log(this.inputObj);
  }
  // close modal popup 
  hide() {
    this.showModal = false;
  }




}
