import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { CommonService } from '../../services/common.service';
 import * as Highcharts from 'highcharts';
 import exporting from 'highcharts/modules/exporting';
exporting(Highcharts); 




import  jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {
 
//   data = [{
//     name: 'CMR',
//     data: [500, 700, 555, 444, 777, 877, 944, 567, 666, 789, 456, 654]
//  },{
//     name: 'SMR',
//     data: [100, 455, 677, 877, 455, 778, 888, 567, 785, 488, 567, 654]
//  }];
 highcharts = Highcharts;
 CMRBarChartOptions: any;
 SMRBarChartOptions: any;
 splineChartOptions: any;
 pieChartOptions: any;
 CMRReadData: any[] = [];
 SMRReadData: any[] = [];
 writeData: any[] = [];
 XAxisCategiries: any[] = [];
 usageStatistics: any;
 avgCMRRead: any;
 avgSMRRead: any;
 avgWrite: any;

 maxCMRRead: any;
 maxSMRRead: any;
 minCMRRead: any;
 minSMRRead: any;
 hideTitles: boolean = true;
   maxLINEARCMRRead: number;
   minLINEARCMRRead: number;
   maxLINEARSMRRead: number;
   minLINEARSMRRead: number;


  constructor(private _activatedRoute: ActivatedRoute,
   private _router: Router, private _commonService: CommonService) { }

  ngOnInit(): void {
   this.hideTitles  = true;
   this._commonService.changecmr(true);

  
   this._commonService.getDriveStatistics().subscribe((data) => {
      console.log('this is response --', data);
      if(data){
         this.getChartsData(data);
      }
    });



   

  }



getChartsData(data: any){
   if(data){
 this.usageStatistics =  data;
 //this.usageStatistics = [{'read': '1.626', 'writ': '0.85'}, {'read': '2.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '2.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '3.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.078'}, {'read': '0.0', 'writ': '0.211'}, {'read': '0.0', 'writ': '0.023'}, {'read': '0.0', 'writ': '0.031'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.141'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '8.047'}, {'read': '0.0', 'writ': '0.188'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.047'}, {'read': '9.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.117'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '3.922'}, {'read': '0.0', 'writ': '0.086'}, {'read': '4.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '5.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'avg_read': 0.03333333333333333}, {'avg_writ': 0.36666666666666664}, {'max_read': 1}, {'max_writ': 8}, {'max_read': 1}, {'min_writ': 0}];
   this.usageStatistics.forEach(item =>{
      if(item.read && item.writ){
      // let writeSizeMB = parseInt(item.writ) / Math.pow(1024,2);
       // let readCMRSizeMB = parseInt(item.read) / Math.pow(1024,2);
       // let readSMRSizeMB = parseInt(readCMRSizeMB) + 10;
      // this.writeData.push(writeSizeMB);

    let readCMRVal = parseInt(item.read);
    let readSMRVal = readCMRVal + 10;
   this.CMRReadData.push(readCMRVal);
   this.SMRReadData.push(readSMRVal);
      }else {
      // this.maxCMRRead = Math.max(...this.CMRReadData);
      // this.minCMRRead = Math.min(...this.CMRReadData);
      // this.maxSMRRead = Math.max(...this.SMRReadData);
      // this.minSMRRead = Math.min(...this.SMRReadData);
      this.maxCMRRead = Math.max(...this.CMRReadData);
      this.minCMRRead = Math.min(...this.CMRReadData);
      this.maxSMRRead = Math.max(...this.SMRReadData);
      this.minSMRRead = Math.min(...this.SMRReadData);
      }
      })
   }
      else{
          // this.avgRead = parseInt(item.avg_read) /  Math.pow(1024,2);
          // this.avgWrite = parseInt(item.avg_writ) /  Math.pow(1024,2);
         //   console.log('item---', item);

          // this.avgCMRRead = parseInt(item.avg_read);
          // this.avgSMRRead = parseInt(this.avgCMRRead) + 10;


          //Note:  Need to remove beow lines for api integration and need to use above two line for api 
         
         
          this.minCMRRead = 4;
          this.minSMRRead = 2;
          this.CMRReadData.push(2, 4);
          this.SMRReadData.push(4, 8);         
          this.avgCMRRead = 10;
          this.avgSMRRead = this.avgCMRRead + 10;       

      }
    
   }
  
  barGraph(){

   this.CMRReadData = [2, 4, 6, 8];
   this.SMRReadData = [4, 8, 10, 12];

   this.maxCMRRead = Math.max(...this.CMRReadData);
   this.minCMRRead = Math.min(...this.CMRReadData);

   this.maxSMRRead = Math.max(...this.SMRReadData);
   this.minSMRRead = Math.min(...this.SMRReadData);


   this.CMRBarChartOptions = {   
    chart: {
       type: "column"
    },
    plotOptions: {
      series: {
         //connectNulls: true
         pointPadding: 20,
         marginRight:20,
		   marginLeft:1,
      }
   },
    title: {
       text: "PERFORMANCE GRAPH – CMR"
    },
    xAxis:{
    categories:[0, 10, 20, 30, 40, 50, 60]
    
    },
    yAxis: {          
       title:{
          text:"Usage Statistics"
       }
      // categories:[0, 450000] 
    },
    series:[{
      name: 'CMR Read Usage',
      data: this.CMRReadData,
      pointWidth: 20
   }]
  };
   console.log(this.CMRBarChartOptions.series);
      

   this.SMRBarChartOptions = {   
      chart: {
         type: "column"
      },
      plotOptions: {
        series: {
           //connectNulls: true
           pointPadding: 20,
           marginRight:20,
        }
     },
      title: {
         text: "PERFORMANCE GRAPH <br> CMR & SMR"
      },
      xAxis:{
      categories:[0, 10, 20, 30, 40, 50, 60]
      
      },
      yAxis: {          
         title:{
            text:"Usage Statistics"
         }
        // categories:[0, 450000] 
      },
      series:[{
        name: 'SMR Read in MBPS',
        data: [2, 4, 6, 8],
        pointWidth: 20
     },
     {
      name: 'CMR Read in MBPS',
      data: [4, 8, 10, 12],
      pointWidth: 20
   }]
    };

    };
    


    linierGraph(){

let cmr =  [2, 4, 1, 3, 4, 2, 9, 1, 2, 3, 4, 5];
let smr =  [5, 8, 2, 6, 8, 4, 18, 2, 4, 6, 10];
this.maxLINEARCMRRead = Math.max(...cmr);
this.minLINEARCMRRead = Math.min(...cmr);
this.maxLINEARSMRRead  =  Math.max(...smr);
this.minLINEARSMRRead =  Math.min(...smr);


      this.splineChartOptions = {   
        chart: {
           type: "spline"
        },
        title: {
           text: "PERFORMANCE GRAPH <br> CMR & SMR"
        },
        xAxis:{
         //  categories:["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        },
        yAxis: {          
           title:{
              text:"Usage Statistics"
           } 
        },
      //   series:[{
      //      name: 'CMR Read Usage <br> Units in Mega Bytes',
      //      data: this.CMRReadData
      //   },{
      //      name: 'SMR Read Usage <br> Units in Mega Bytes',
      //      data: this.SMRReadData
      //   }]
      series: [{
         name: 'CMR Read in MBPS',
         data: [2, 4, 1, 3, 4, 2, 9, 1, 2, 3, 4, 5],
         dashStyle: 'shortdot'
       }, {
         name: 'SMR Read in MBPS',
         data: [5, 8, 2, 6, 8, 4, 18, 2, 4, 6, 10],
       },
       {
         name: 'SMR',
         data: [25, 28, 20, 26, 18, 24, 29, 20, 27, 22, 30],
       },
       {
         name: 'CMR',
         data: [20, 19, 17, 18, 17, 20, 21, 22, 24, 20, 19],
       }]
      };
    
  
  };


 
  exportPDF(){
   // parentdiv is the html element which has to be converted to PDF
  
   html2canvas(document.querySelector("#parentdiv")).then(canvas => {

      var pdf = new jsPDF('p', 'pt', 'a4');

      var imgData  = canvas.toDataURL("image/jpeg", 1.0);
      pdf.addImage(imgData,15, 15, 500, 450);
      pdf.save('CMR_SMR_PerformanceCharts.pdf');

  });
  
   console.log(Highcharts);
}

goToHome(){
   this._router.navigateByUrl('/home');
}
}
