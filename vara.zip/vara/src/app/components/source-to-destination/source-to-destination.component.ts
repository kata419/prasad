import { Component, OnInit, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-source-to-destination',
  templateUrl: './source-to-destination.component.html',
  styleUrls: ['./source-to-destination.component.css']
})
export class SourceToDestinationComponent implements OnInit {
  @Input() item: any;
  ngOnInit(): void {
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    this.item = changes.item.currentValue;
  }

}
