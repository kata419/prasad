import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediachartsComponent } from './mediacharts.component';

describe('MediachartsComponent', () => {
  let component: MediachartsComponent;
  let fixture: ComponentFixture<MediachartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediachartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediachartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
