import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SourcetodestinationComponent } from './sourcetodestination.component';

describe('SourcetodestinationComponent', () => {
  let component: SourcetodestinationComponent;
  let fixture: ComponentFixture<SourcetodestinationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SourcetodestinationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SourcetodestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
