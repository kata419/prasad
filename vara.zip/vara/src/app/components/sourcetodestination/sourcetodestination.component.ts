import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sourcetodestination',
  templateUrl: './sourcetodestination.component.html',
  styleUrls: ['./sourcetodestination.component.css']
})
export class SourcetodestinationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
