import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceToDestinationComponent } from './source-to-destination.component';

describe('SourceToDestinationComponent', () => {
  let component: SourceToDestinationComponent;
  let fixture: ComponentFixture<SourceToDestinationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SourceToDestinationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceToDestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
