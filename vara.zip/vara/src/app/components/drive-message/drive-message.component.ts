import { Component, OnInit, EventEmitter, Output  } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router} from '@angular/router';

@Component({
  selector: 'app-drive-message',
  templateUrl: './drive-message.component.html',
  styleUrls: ['./drive-message.component.css']
})
export class DriveMessageComponent implements OnInit {

  constructor(private _router : Router, private _activatedRouter : ActivatedRoute) { }

  ngOnInit(): void {
    setTimeout(() => {
      this._router.navigateByUrl('/home');
      }, 10000);
  }

}
