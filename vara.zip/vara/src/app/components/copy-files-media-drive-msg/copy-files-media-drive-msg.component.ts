import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copy-files-media-drive-msg',
  templateUrl: './copy-files-media-drive-msg.component.html',
  styleUrls: ['./copy-files-media-drive-msg.component.css']
})
export class CopyFilesMediaDriveMsgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
