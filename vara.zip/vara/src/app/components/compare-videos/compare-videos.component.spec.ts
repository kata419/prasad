import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompareVideosComponent } from './compare-videos.component';

describe('CompareVideosComponent', () => {
  let component: CompareVideosComponent;
  let fixture: ComponentFixture<CompareVideosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompareVideosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompareVideosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
