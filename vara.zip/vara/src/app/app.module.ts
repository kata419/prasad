import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CompareVideosComponent } from './components/compare-videos/compare-videos.component';
import { ChartsComponent } from './components/charts/charts.component';
import { HomeComponent } from './components/home/home.component';
import { PlayVideosComponent } from './components/play-videos/play-videos.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { CmrsmrComparisonComponent } from './components/cmrsmr-comparison/cmrsmr-comparison.component';

import { DriveMessageComponent } from './components/drive-message/drive-message.component'
import { HelpComponent } from './components/help/help.component'

import { CommonService } from './services/common.service';

import { HighchartsChartModule } from 'highcharts-angular';


import { SourceToDestinationComponent } from './components/source-to-destination/source-to-destination.component';


import { ReactiveFormsModule } from '@angular/forms';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { CopyFilesToMediaMsgComponent } from './components/copy-files-to-media-msg/copy-files-to-media-msg.component';
import { WhilePlayingVideosComponent } from './components/while-playing-videos/while-playing-videos.component';
import { CopyFilesWhilePlayingMediaComponent } from './components/copy-files-while-playing-media/copy-files-while-playing-media.component';
import { CopyFilesMediaDriveMsgComponent } from './components/copy-files-media-drive-msg/copy-files-media-drive-msg.component';
import { MediachartsComponent } from './components/mediacharts/mediacharts.component';
import { ChartRWComponent } from './components/chart-rw/chart-rw.component';
import { timer, Observable, Subscription } from 'rxjs';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    CompareVideosComponent,
    ChartsComponent,
    HomeComponent,
    PlayVideosComponent,
    FileUploadComponent,
    CmrsmrComparisonComponent,
    DriveMessageComponent,
    HelpComponent,
    SourceToDestinationComponent,
    CopyFilesToMediaMsgComponent,
    WhilePlayingVideosComponent,
    CopyFilesWhilePlayingMediaComponent,
    CopyFilesMediaDriveMsgComponent,
    MediachartsComponent,
    ChartRWComponent  
  ],
  imports: [
    BrowserModule, 
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule,
    HighchartsChartModule,
    ReactiveFormsModule, 
    MatProgressBarModule
  
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]


  
    // { provide: HIGHCHARTS_MODULES, useFactory: () => [ more, exporting ] }
})
export class AppModule { }
