import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyFilesToMediaMsgComponent } from './copy-files-to-media-msg.component';

describe('CopyFilesToMediaMsgComponent', () => {
  let component: CopyFilesToMediaMsgComponent;
  let fixture: ComponentFixture<CopyFilesToMediaMsgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyFilesToMediaMsgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyFilesToMediaMsgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
