import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../../services/common.service'
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-while-playing-videos',
  templateUrl: './while-playing-videos.component.html',
  styleUrls: ['./while-playing-videos.component.css']
})
export class WhilePlayingVideosComponent implements OnInit {
destinationPath:any;
sourcePath:any;
sectionName:any;
copyData:any = {};
@Input() dataObj:any;
  showMessage: boolean;
  inputObj: any ={};
  constructor(private _commonService: CommonService, private _activatedRoute: ActivatedRoute,
    private _router: Router, private location: Location) { }

  ngOnInit(): void {
  
  this.sectionName = this._activatedRoute.snapshot.queryParams;
    this.location.replaceState('while-play-videos');
    console.log(this.sectionName);
    this._commonService.changecmr(false);

  }
  uploadData(filepath: any) {

    // console.dir('value--'+filepath.target.value);

    // console.dir('result--'+filepath.target.result);

debugger;
    let url: any, format: any, fileProperties: any;
    this.inputObj['uploadedFiles'] = [];
    // console.log('filepath--',filepath);

    // console.log('filepath--', filepath.path.window);

    // let file = filepath.target.files && filepath.target.files[0];
    let file = filepath.target.files;
    // console.log('file---', file);


    if (file) {

      for (let i = 0; i < file.length; i++) {
        var reader = new FileReader();
        reader.readAsDataURL(file[i]);
        if (file[i].type.indexOf('image') > -1) {
          format = 'image';
        } else if (file[i].type.indexOf('video') > -1) {
          format = 'video';
        }
        reader.onload = (event) => {
          url = (<FileReader>event.target).result;
          // console.log(JSON.stringify(url));
          fileProperties = {
            'fileType': file[i].type,
            'file': url
          }
          this.inputObj['uploadedFiles'].push(fileProperties);
          


          // this.inputObj = {
          //   'sourcePath':this.sourcePath,
          //   'destinationPath':this.destinationPath
          // }

        //  this._commonService.setUploadedFilesInfo(this.inputObj);

        }
      }
      // console.log(this.inputObj);
      this.showMessage = true;
      setTimeout(() => {
        this.showMessage = false;
        // this._router.navigateByUrl('/copyfiles-whileplaying-media');
      }, 3000);
    }
    // console.log(this.inputObj);
  }
  copyFilestoMedia(){     
    // this._router.navigate(['while-play-videos'], { queryParams: this.inputObj});

    this.inputObj['sourcePath'] = this.sourcePath;
    this.inputObj['destinationPath'] = this.destinationPath;

    this.inputObj['driveName'] = this.sectionName.driveName;
    this.inputObj['count'] = this.sectionName.count;
    this.inputObj['itemType'] = this.sectionName.itemType;
    debugger;
    //this.inputObj['uploadedFiles'] = this.sectionName.itemType;
    console.log(this.inputObj);

    this._commonService.setUploadedFilesInfo(this.inputObj);

    this._router.navigateByUrl('/copyfiles-whileplaying-media');

  }
}
