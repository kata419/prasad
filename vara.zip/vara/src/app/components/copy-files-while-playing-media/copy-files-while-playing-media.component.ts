import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { CommonService } from '../../services/common.service'
import { timer, Observable, Subscription } from 'rxjs';
import { map, takeWhile, tap } from 'rxjs/operators';
import $ from 'jquery';
// import { Observable } from 'rxjs';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ThemePalette } from '@angular/material/core';
import { ProgressBarMode } from '@angular/material/progress-bar';

@Component({
  selector: 'app-copy-files-while-playing-media',
  templateUrl: './copy-files-while-playing-media.component.html',
  styleUrls: ['./copy-files-while-playing-media.component.css']
})
export class CopyFilesWhilePlayingMediaComponent implements OnInit {
  getSelectedFilesData:any = {};
  videosList: any = [];
  playAll: boolean = false;
  pauseAll: boolean = true;
  // Pagination 
  page = 1;
  pageSize = 8;

  showModal: boolean;
 // @Input() videoURL: any;
 videoURL: any;

  hours: any;
  minutes: any;
  seconds: any;

  private subscriptions: Subscription[] = [];
  everySecond$: Observable<number> = timer(0, 1000);
  //timer$: Observable<number>;
  quotient: any;
  remainder: any;

  selectedFiles: any[] = [];

copyData:any = {}
  // Progress bar

  color: ThemePalette = 'primary';
  mode: ProgressBarMode = 'buffer';
  value = 50;
  bufferValue: number;
  timer;


   hideCopying: boolean =  true;
  constructor(private _commonService: CommonService,
    private _activatedRoute: ActivatedRoute,
    private _router: Router) { }


    ngOnInit(): void {

      this.getSelectedFilesData = this._commonService.getUploadedFilesInfo();
      console.log('reponse --  ', this.getSelectedFilesData);
      this._commonService.changecmr(false);

      if (Object.keys(this.getSelectedFilesData).length === 0 && this.getSelectedFilesData.constructor === Object) {
        console.log('this is empty obj', this.getSelectedFilesData);
        this._router.navigateByUrl('/home');
      }
      else {
        let inputObj = {
          'source': this.getSelectedFilesData.sourcePath,
          'destination': this.getSelectedFilesData.destinationPath
	  }
        this._commonService.copyFilesToMedia(inputObj).subscribe((data) => {
      console.log('this is response --', data);

      this.copyData = data;
    });

	this.timer = setInterval(() => this.startProgressBar(inputObj), 10000)
        let largeVal = Math.max(this.getSelectedFilesData.count, this.getSelectedFilesData.uploadedFiles.length);
        let smallVal = Math.min(this.getSelectedFilesData.count, this.getSelectedFilesData.uploadedFiles.length);
        this.quotient = Math.floor(largeVal / smallVal);
        this.remainder = largeVal % smallVal;
        console.log('quotient--', this.quotient + 'remainder--' + this.remainder);
        
        if (this.getSelectedFilesData.itemType === 'same') {
          // this.videosList = new Array(this.getSelectedFilesData.count).fill(this.getSelectedFilesData.uploadedFiles[0]);
          this.videosList = new Array(this.quotient).fill(this.getSelectedFilesData.uploadedFiles[0]);

          let videosList = [];
         for(let n = 0; n < this.videosList.length; n++){
          videosList.push({
            "id": n+1,
            "posterImg": this.videosList[n].posterImg,
            "file": this.videosList[n].file
          })
         }
  
        this.videosList = videosList;
  
        }
        else{
          let i: any;
          for (i = 0; i < this.getSelectedFilesData.uploadedFiles.length; i++) {
            let fileObj = {
              "id": i + 1,
              "posterImg": "https://www.w3schools.com/images/w3schools_green.jpg",
              "file": this.getSelectedFilesData.uploadedFiles[i].file
            }
  
            this.videosList.push(fileObj);
  
            // if (i + 1 == this.getSelectedFilesData.uploadedFiles.length && remainder != 0) {
            //   // this.videosList = new Array(this.quotient + this.remainder).fill(fileObj);
            //   this.videosList = this.videosList.concat(Array(this.quotient + this.remainder).fill(fileObj));
            // }
            // else if (i + 1 == this.getSelectedFilesData.uploadedFiles.length && remainder == 0) {
            //  // this.videosList = new Array(this.quotient).fill(fileObj);
            //  this.videosList = this.videosList.concat(Array(this.quotient).fill(fileObj));
            // }
            // else if (i + 1 != this.getSelectedFilesData.uploadedFiles.length && remainder == 0) {
            //   // this.videosList = new Array(this.quotient).fill(fileObj);
            //   this.videosList = this.videosList.concat(Array(this.quotient).fill(fileObj));
            //  }
      
        } 
        
        let tempDupilcatesLust = [];
        
         
     
        tempDupilcatesLust = Array.from({ length: parseInt(this.quotient) * this.videosList.length }, (_, i) => this.videosList[i % this.videosList.length]);
  
        console.log('tempDupilcatesLust----',tempDupilcatesLust);
  
      //  this.videosList = tempDupilcatesLust;



      if(this.remainder != 0){
        // tempDupilcatesLust.push(tempDupilcatesLust[0] * this.remainder);
     
     
         let tempAry = [];
         for(let i = 0; i <  tempDupilcatesLust.length; i++){
           let videoObj = {
             "id": i + 1,
             "posterImg": "https://www.w3schools.com/images/w3schools_green.jpg",
             "file": tempDupilcatesLust[i].file
           }
         
           tempAry.push(videoObj);
         
         }
     
         for (let k = 0; k < this.remainder; k++) {
           let firstVideo = {
             "id": tempAry.length + 1,
             "posterImg": "https://www.w3schools.com/images/w3schools_green.jpg",
             "file": tempAry[0].file
           };
     
           tempAry.push(firstVideo);
         }
     
         this.videosList = tempAry;
     
       }
       else{
       //  tempDupilcatesLust.push(tempDupilcatesLust[0] * this.remainder);
     
     
         let tempAry = [];
         for(let i = 0; i <  tempDupilcatesLust.length; i++){
           let videoObj = {
             "id": i + 1,
             "posterImg": "https://www.w3schools.com/images/w3schools_green.jpg",
             "file": tempDupilcatesLust[i].file
           }
         
           tempAry.push(videoObj);
         
         }
         this.videosList = tempAry;
     
       }
  
  
  
    
          
    
  
  
      }
  
  
      
  
  
        // this.videosList.push(
        //   {
        //     "id": i + 1,
        //     "posterImg": "https://www.w3schools.com/images/w3schools_green.jpg",
        //     "url": this.getSelectedFilesData.uploadedFiles[i].file
        //   }
        // );
      }
  
  
  
      console.log('this.videoList--', this.videosList);
      this.startTimer();
      

      this.usageStatistics('StartStatistics');
  
    }




    startTimer() {

      //     this.subscription = this.timer$.subscribe(seconds => this.time_convert(seconds) );
      // console.log(this.subscription);
  
      this.subscriptions.push(this.everySecond$.subscribe(second => this.time_convert(second)));
  
    }
  
    time_convert(num: number) {
      this.hours = Math.floor(num / 3600);;
      num %= 3600;
      this.minutes = Math.floor(num / 60);
      this.seconds = num % 60;
      // console.log(this.hours, this.minutes, this.seconds);
  
  
    }
    usageStatistics(flag: any) {
      this._commonService.usageStatistics(flag).subscribe((data) => {
        console.log('load Usage Statistics --', data);
  
        // Vamshi :  Please provide me response header
  
  
      });
    }
    playAndPauseVideo(value: any) {
      if (value == 'play') {
        $(".videobrdr").each(function () {
          $(this).get(0).play();
        });
        this.pauseAll = true;
        this.playAll = false;
      }
      else {
  
        this.pauseAll = false;
        this.playAll = true;
        $(".videobrdr").each(function () {
          $(this).get(0).pause();
        });
      }
  
    };
  
    openPopup(selectedVideo: any) {
  
  
  
      this.showModal = true;
      console.log('video index', selectedVideo);
      this.videoURL = selectedVideo.file;
    }
    hide() {
      this.showModal = false;
      this.videoURL = '';
    }
    stopExit() {
  
      clearInterval(this.timer);

      this.subscriptions.forEach(subscription => subscription.unsubscribe());
  
      this.usageStatistics('StopStatistics');
      if (this.getSelectedFilesData.driveName === 'CMR') {
        this._router.navigateByUrl('/drive-msg');
      }
      if (this.getSelectedFilesData.driveName === 'SMR') {
        this._router.navigateByUrl('/chart-rw');
      }
    }
    loadVideosList(inputObj) {
      this._commonService.loadCMRVideoUrls(inputObj).subscribe((data) => {
        console.log('this is response --', data);
  
  
        // if (data.length > 0) {
        //   this.usageStatistics();
        // }
  
        // Please comment static data when you got api response
        // Please send cvs file to generate graphs
        //  this.videosList = data;
  
      });
    }
    async startProgressBar(inputObj: any) {
  
      this._commonService.progressFilesToMedia(inputObj).subscribe((data) => {
        console.log('progress value --', data);
  
        this.copyData = data;
        this.bufferValue = this.copyData.msg.percentagecopied;
        if (this.bufferValue == 100) {
          clearInterval(this.timer);
        }


      });


      
  
    }
    stopCopying(){
       this._commonService.stopcopying().subscribe((data) => {
        console.log('load Usage Statistics --', data);


      });

      }
}
