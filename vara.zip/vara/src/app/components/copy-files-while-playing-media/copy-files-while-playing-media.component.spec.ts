import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyFilesWhilePlayingMediaComponent } from './copy-files-while-playing-media.component';

describe('CopyFilesWhilePlayingMediaComponent', () => {
  let component: CopyFilesWhilePlayingMediaComponent;
  let fixture: ComponentFixture<CopyFilesWhilePlayingMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyFilesWhilePlayingMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyFilesWhilePlayingMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
