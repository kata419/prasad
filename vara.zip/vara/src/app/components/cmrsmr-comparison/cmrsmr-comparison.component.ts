import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmrsmr-comparison',
  templateUrl: './cmrsmr-comparison.component.html',
  styleUrls: ['./cmrsmr-comparison.component.css']
})
export class CmrsmrComparisonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
