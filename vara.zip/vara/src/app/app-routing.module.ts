import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChartsComponent } from './components/charts/charts.component';
import { CompareVideosComponent } from './components/compare-videos/compare-videos.component'; 
import { HomeComponent } from './components/home/home.component'; 
import { PlayVideosComponent} from './components/play-videos/play-videos.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { CmrsmrComparisonComponent } from './components/cmrsmr-comparison/cmrsmr-comparison.component';
import { DriveMessageComponent } from './components/drive-message/drive-message.component';
import { HelpComponent } from './components/help/help.component';
import { SourceToDestinationComponent } from './components/source-to-destination/source-to-destination.component'
import { CopyFilesToMediaMsgComponent } from './components/copy-files-to-media-msg/copy-files-to-media-msg.component';
import { WhilePlayingVideosComponent } from './components/while-playing-videos/while-playing-videos.component';
import { CopyFilesWhilePlayingMediaComponent } from './components/copy-files-while-playing-media/copy-files-while-playing-media.component';
import { from } from 'rxjs';

import { MediachartsComponent } from './components/mediacharts/mediacharts.component';
import { ChartRWComponent } from './components/chart-rw/chart-rw.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'help',  component: HelpComponent, pathMatch: 'full' },
  { path: 'charts',  component: ChartsComponent, pathMatch: 'full' }, 
  { path: 'play-videos',  component: PlayVideosComponent, pathMatch: 'full' },
  { path: 'home',  component: HomeComponent, pathMatch: 'full' },
  { path: 'compare-videos',  component: CompareVideosComponent,  pathMatch: 'full' },
  { path: 'file-upload',  component: FileUploadComponent, pathMatch: 'full' },
  { path: 'cmrsmr-comparision', component: CmrsmrComparisonComponent, pathMatch: 'full'},
  { path: 'drive-msg', component: DriveMessageComponent, pathMatch: 'full' },
  { path: 'source-to-destination', component: SourceToDestinationComponent, pathMatch: 'full' },
  { path: 'copyfiles-mediamsg', component: CopyFilesToMediaMsgComponent, pathMatch: 'full' },
  { path: 'while-play-videos',component:WhilePlayingVideosComponent,pathMatch:'full'},
  { path: 'copyfiles-whileplaying-media', component:CopyFilesWhilePlayingMediaComponent,pathMatch:'full'},
  { path: 'media-charts', component:MediachartsComponent,pathMatch:'full'},
  { path: 'chart-rw', component:ChartRWComponent, pathMatch:'full'}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
