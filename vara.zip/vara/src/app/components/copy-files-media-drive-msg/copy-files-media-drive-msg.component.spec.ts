import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyFilesMediaDriveMsgComponent } from './copy-files-media-drive-msg.component';

describe('CopyFilesMediaDriveMsgComponent', () => {
  let component: CopyFilesMediaDriveMsgComponent;
  let fixture: ComponentFixture<CopyFilesMediaDriveMsgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyFilesMediaDriveMsgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyFilesMediaDriveMsgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
