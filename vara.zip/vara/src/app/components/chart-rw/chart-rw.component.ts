import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { CommonService } from '../../services/common.service';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
exporting(Highcharts);

import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-chart-rw',
  templateUrl: './chart-rw.component.html',
  styleUrls: ['./chart-rw.component.css']
})
export class ChartRWComponent implements OnInit {

  //   data = [{
  //     name: 'CMR',
  //     data: [500, 700, 555, 444, 777, 877, 944, 567, 666, 789, 456, 654]
  //  },{
  //     name: 'SMR',
  //     data: [100, 455, 677, 877, 455, 778, 888, 567, 785, 488, 567, 654]
  //  }];
  highcharts = Highcharts;
  CMRBarChartOptions: any;
  SMRBarChartOptions: any;
  splineChartOptions: any;
  pieChartOptions: any;
  CMRReadData: any[] = [];
  SMRReadData: any[] = [];
  writeData: any[] = [];
  XAxisCategiries: any[] = [];
  usageStatistics: any;
  avgCMRRead: any;
  avgSMRRead: any;
  avgWrite: any;

  maxCMRRead: any;
  maxSMRRead: any;
  minCMRRead: any;
  minSMRRead: any;
  hideTitles: boolean = true;
  maxLINEARCMRRead: number;
  minLINEARCMRRead: number;
  maxLINEARSMRRead: number;
  minLINEARSMRRead: number;
  maxCMRWrite: any = [];
  CMRWriteData: any = [];
  minCMRWrite: number;
  minSMRWrite: number;
  maxSMRWrite: number;
  SMRWriteData: any = [];


  constructor(private _activatedRoute: ActivatedRoute,
    private _router: Router, private _commonService: CommonService) { }

  ngOnInit(): void {
    
    this.hideTitles = true;
    this._commonService.changecmr(true);
    this._commonService.getDriveStatistics().subscribe((data) => {
      console.log('this is response --', data);
      if (data) {
        this.getChartsData(data);
      }
    });





  }



  getChartsData(data?) {
    
    if (data) {
      this.usageStatistics = data.msg;
      //this.usageStatistics = [{'read': '1.626', 'writ': '0.85'}, {'read': '2.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '2.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '3.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.078'}, {'read': '0.0', 'writ': '0.211'}, {'read': '0.0', 'writ': '0.023'}, {'read': '0.0', 'writ': '0.031'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.141'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '8.047'}, {'read': '0.0', 'writ': '0.188'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.047'}, {'read': '9.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.117'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '3.922'}, {'read': '0.0', 'writ': '0.086'}, {'read': '4.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'read': '5.0', 'writ': '0.0'}, {'read': '0.0', 'writ': '0.0'}, {'avg_read': 0.03333333333333333}, {'avg_writ': 0.36666666666666664}, {'max_read': 1}, {'max_writ': 8}, {'max_read': 1}, {'min_writ': 0}];
      this.usageStatistics.forEach(item => {
        if (item.read && item.writ) {
          // let writeSizeMB = parseInt(item.writ) / Math.pow(1024,2);
          // let readCMRSizeMB = parseInt(item.read) / Math.pow(1024,2);
          // let readSMRSizeMB = parseInt(readCMRSizeMB) + 10;
          // this.writeData.push(writeSizeMB);

          let readCMRVal = parseInt(item.read);
          let readSMRVal = readCMRVal + 10;
          let writeCMRVal = parseInt(item.writ);
          let writeSMRVal = writeCMRVal+10;


          this.CMRWriteData.push(writeCMRVal);
          this.SMRWriteData.push(writeSMRVal);
          this.CMRReadData.push(readCMRVal);
          this.SMRReadData.push(readSMRVal);

        } else {
          this.maxCMRRead = parseInt(item.max_read);
          this.minCMRRead = parseInt(item.min_read);
          this.maxSMRRead = parseInt(item.max_read + 10);
          this.minSMRRead = parseInt(item.min_read + 10);

          this.maxCMRWrite = parseInt(item.max_writ);
          this.minCMRWrite = parseInt(item.min_writ);
          this.maxSMRWrite = parseInt(item.max_writ + 10);
          this.minSMRWrite = parseInt(item.min_writ + 10);
        }
      })
    }
    else {
          this.CMRWriteData.push(2,4);
          this.SMRWriteData.push(6,8);
          this.CMRReadData.push(6,8);
          this.SMRReadData.push(10,12);

          this.maxCMRRead = 10;
          this.minCMRRead = 5;
          this.maxSMRRead = 20;
          this.minSMRRead = 10;

          this.maxCMRWrite = 12;
          this.minCMRWrite = 2;
          this.maxSMRWrite = 20;
          this.minSMRWrite = 8;
    }

  }

  barGraph() {
    this.CMRBarChartOptions = {
      chart: {
        type: "column"
      },
      plotOptions: {
        series: {
          pointPadding: 20,
          marginRight: 20,
          marginLeft: 1,
        }
      },
      title: {
        text: "PERFORMANCE GRAPH – CMR"
      },
      xAxis: {
        categories: [0, 10, 20, 30, 40, 50, 60]

      },
      yAxis: {
        title: {
          text: "Usage Statistics"
        }
      },
      series: [{
        name: 'CMR Read Usage',
        data: this.CMRReadData,
        pointWidth: 20
      }]
    };
    console.log(this.CMRBarChartOptions.series);


    this.SMRBarChartOptions = {
      chart: {
        type: "column"
      },
      plotOptions: {
        series: {
          //connectNulls: true
          pointPadding: 20,
          marginRight: 20,
        }
      },
      title: {
        text: "PERFORMANCE GRAPH <br> CMR & SMR"
      },
      xAxis: {
        categories: [0, 10, 20, 30, 40, 50, 60]

      },
      yAxis: {
        title: {
          text: "Usage Statistics"
        }
      },
      series: [{
        name: 'SMR Read in MBPS',
        data: this.SMRReadData,
        pointWidth: 20
      },
      {
        name: 'CMR Read in MBPS',
        data: this.CMRReadData,
        pointWidth: 20
      },
      {
        name: 'SMR Write in MBPS',
        data: this.SMRWriteData,
        pointWidth: 20
      },
      {
        name: 'CMR Write in MBPS',
        data: this.CMRWriteData,
        pointWidth: 20
      }]
    };

  };



  linierGraph() {

    // let cmr = [2, 4, 1, 3, 4, 2, 9, 1, 2, 3, 4, 5];
    // let smr = [5, 8, 2, 6, 8, 4, 18, 2, 4, 6, 10];
    // this.maxLINEARCMRRead = Math.max(...cmr);
    // this.minLINEARCMRRead = Math.min(...cmr);
    // this.maxLINEARSMRRead = Math.max(...smr);
    // this.minLINEARSMRRead = Math.min(...smr);


    this.splineChartOptions = {
      chart: {
        type: "spline"
      },
      title: {
        text: "PERFORMANCE GRAPH <br> CMR & SMR"
      },
      xAxis: {
        //  categories:["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
      },
      yAxis: {
        title: {
          text: "Usage Statistics"
        }
      },
      series: [{
        name: 'SMR Read in MBPS',
        data: this.SMRReadData,
        pointWidth: 20,
        dashStyle: 'shortdot'

      },
      {
        name: 'CMR Read in MBPS',
        data: this.CMRReadData,
        pointWidth: 20
      },
      {
        name: 'SMR Write in MBPS',
        data: this.SMRWriteData,
        pointWidth: 20
      },
      {
        name: 'CMR Write in MBPS',
        data: this.CMRWriteData,
        pointWidth: 20,
        dashStyle: 'shortdot'
      }]
    };


  };



  exportPDF() {
    // parentdiv is the html element which has to be converted to PDF

    html2canvas(document.querySelector("#parentdiv")).then(canvas => {

      var pdf = new jsPDF('p', 'pt', 'a4');

      var imgData = canvas.toDataURL("image/jpeg", 1.0);
      pdf.addImage(imgData, 15, 15, 500, 450);
      pdf.save('CMR_SMR_PerformanceCharts.pdf');

    });

    console.log(Highcharts);
  }

  goToHome() {
    this._router.navigateByUrl('/home');
  }
}
