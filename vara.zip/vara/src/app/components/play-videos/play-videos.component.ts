import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-play-videos',
  templateUrl: './play-videos.component.html',
  styleUrls: ['./play-videos.component.css']
})
export class PlayVideosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
