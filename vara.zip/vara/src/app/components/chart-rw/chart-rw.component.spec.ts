import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartRWComponent } from './chart-rw.component';

describe('ChartRWComponent', () => {
  let component: ChartRWComponent;
  let fixture: ComponentFixture<ChartRWComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartRWComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartRWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
